# alpha_hackz_20
ZF Sportify

Step1:

download mongo db and start it in local.

create DB <sports-booking-db>

Step2:

/backend

npm init -y

npm install express nodemon mongoose body-parser dotenv cors bcryptjs jsonwebtoken

Step3:

create .env inside backend folder
add

MONGO_URI ="mongodb://localhost:27017/sports-booking-db"

Step4:

update pakage.json

  "scripts": {
    "test": "echo \"Error: no test specified\" && exit 1",
    "start": "nodemon server.js"
  },


step5:

npm start








