// Function to fetch and display sports
async function showSports() {
  try {
    const response = await fetch('http://localhost:5001/sports');
    if (!response.ok) throw new Error('Failed to fetch sports data.');

    const sports = await response.json();
    const sportsDiv = document.getElementById('sports');

    sportsDiv.innerHTML = sports
      .map(
        (sport) => `
        <div>
          <h3>${sport.name}</h3>
          ${sport.timeSlots
            .map(
              (slot) => `
            <p>${slot.time}: ${slot.slotsFree} slots available</p>
          `
            )
            .join('')}
        </div>
      `
      )
      .join('');
  } catch (err) {
    console.error('Error loading sports:', err);
    alert('Error loading sports. Please try again.');
  }
}

// Function to handle signup
async function handleSignup(event) {
  event.preventDefault();

  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  const userData = { name, email, password };

  try {
    const response = await fetch('http://localhost:5001/api/signup', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(userData),
    });

    if (response.ok) {
      const result = await response.json();
      alert('User signed up successfully!');
      window.location.href = 'login.html';
    } else {
      const error = await response.json();
      alert('Signup failed: ' + error.message);
    }
  } catch (err) {
    console.error('Error during signup:', err);
    alert('An error occurred. Please try again.');
  }
}

// Function to handle login
async function handleLogin(event) {
  event.preventDefault();

  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  const userData = { email, password };

  try {
    const response = await fetch('http://localhost:5001/api/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(userData),
    });

    if (response.ok) {
      const result = await response.json();
      alert('Login successful!');
      localStorage.setItem('token', result.token);
      window.location.href = 'index.html'; // Redirect to the dashboard
    } else {
      const error = await response.json();
      alert('Login failed: ' + error.message);
    }
  } catch (err) {
    console.error('Error during login:', err);
    alert('An error occurred. Please try again.');
  }
}


async function fetchAvailableSlots() {
  const date = document.getElementById('date').value;
  const timeSlotDropdown = document.getElementById('timeSlot');

  if (!date) return;

  try {
    const response = await fetch(`http://localhost:5001/api/slots?date=${date}`);
    if (!response.ok) throw new Error('Failed to fetch slots.');

    const slots = await response.json();

    // Populate the dropdown with available slots
    timeSlotDropdown.innerHTML = slots
      .map(slot => `<option value="${slot.time}">${slot.time} (${slot.slotsFree} slots available)</option>`)
      .join('');
  } catch (err) {
    console.error('Error fetching slots:', err);
    alert('Error fetching slots. Please try again.');
  }
}


async function handleCricketBooking(event) {
  event.preventDefault();

  const date = document.getElementById('date').value;
  const timeSlot = document.getElementById('timeSlot').value;

  if (!date || !timeSlot) {
    alert('Please select a date and time slot.');
    return;
  }

  const bookingData = { date, timeSlot };

  try {
    const response = await fetch('http://localhost:5001/api/book', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(bookingData),
    });

    if (response.ok) {
      const result = await response.json();
      alert(`Booking successful! Slot ${timeSlot} on ${date} is confirmed.`);
      fetchAvailableSlots(); // Refresh available slots
    } else {
      const error = await response.json();
      alert('Booking failed: ' + error.message);
    }
  } catch (err) {
    console.error('Error during booking:', err);
    alert('An error occurred. Please try again.');
  }
}



