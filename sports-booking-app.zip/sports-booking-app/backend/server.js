
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');
const jwt = require('jsonwebtoken');
const Slot = require('./models/Slot');


const app = express();
app.use(cors());
app.use(bodyParser.json());

// Routes
const authRoutes = require('./routes/auth');
const sportsRoutes = require('./routes/sports');
const bookingRoutes = require('./routes/booking');

app.use('/auth', authRoutes);
app.use('/sports', sportsRoutes);
app.use('/booking', bookingRoutes);


// Debug the URI (optional for troubleshooting)
mongoose.connect(process.env.MONGO_URI, {
}).then(() => {
  console.log('Connected to MongoDB');
}).catch((err) => console.log(err));

// Registration Endpoint
app.post('/api/signup', async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Check if user already exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    // Create new user
    const newUser = new User({ name, email, password });
    await newUser.save();

    res.status(201).json({ message: 'User registered successfully' });
  } catch (err) {
    console.error('Error creating user:', err);
    res.status(500).json({ message: 'Internal Server Error' });
  }
});




app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;

  try {
    // Find user by email
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }

    if (password != user.password) {
      return res.status(400).json({ message: 'Invalid email or password' });
    }
    const token = jwt.sign({ id: user._id, email: user.email }, 'secretkey', { expiresIn: '1h' });
    res.status(200).json({ message: 'Login successful', token});
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
});

const defaultTimes = ['9am-10am', '10am-11am', '11am-12pm'];

app.get('/api/slots', async (req, res) => {
  const { date } = req.query;

  try {
    // Check if slots exist for the given date
    let slots = await Slot.find({ date });
    
    if (slots.length === 0) {
      // Auto-create slots if not present
      const newSlots = defaultTimes.map(time => ({
        date,
        time,
        slotsFree: 5,
        isBlocked: false,
      }));
      slots = await Slot.insertMany(newSlots);
    }

    // Return available slots
    const availableSlots = slots.filter(slot => !slot.isBlocked);
    res.status(200).json(availableSlots);
  } catch (err) {
    console.error('Error fetching slots:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
});


app.post('/api/book', async (req, res) => {
  const { date, timeSlot } = req.body;

  try {
    // Find the slot for the given date and time
    const slot = await Slot.findOne({ date, time: timeSlot });
    if (!slot || slot.slotsFree <= 0 || slot.isBlocked) {
      return res.status(400).json({ message: 'Slot not available' });
    }

    // Decrease slot count and block if fully booked
    slot.slotsFree -= 1;
    if (slot.slotsFree === 0) slot.isBlocked = true;
    await slot.save();

    res.status(201).json({ message: 'Booking confirmed!' });
  } catch (err) {
    console.error('Error booking slot:', err);
    res.status(500).json({ message: 'Internal server error' });
  }
});


const PORT = process.env.PORT || 5001;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
