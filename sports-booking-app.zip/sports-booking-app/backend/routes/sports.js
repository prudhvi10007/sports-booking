const express = require('express');
const Sport = require('../models/Sport');
const router = express.Router();

// Get all sports and slots
router.get('/', async (req, res) => {
  try {
    const sports = await Sport.find();
    res.json(sports);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
